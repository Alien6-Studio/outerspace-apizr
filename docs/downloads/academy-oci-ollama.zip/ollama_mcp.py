"""A small local Ollama tool-calling bridge to an Apizr-generated MCP image."""
import asyncio
import json
import shutil
import sys
import textwrap
import urllib.request
from pathlib import Path
from mcp import Client, StdioServerParameters

MODEL = 'qwen3-coder:30b'
IMAGE = 'apizr-academy:05-shop-mcp'


def chat(messages, tools):
    payload = dict(model=MODEL, messages=messages, tools=tools, stream=False,
        keep_alive='10m', options=dict(temperature=0, num_ctx=4096, num_predict=300))
    request = urllib.request.Request('http://127.0.0.1:11434/api/chat',
        data=json.dumps(payload).encode(), headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request, timeout=240) as response:
        return json.load(response)


async def main():
    server = StdioServerParameters(command=shutil.which('docker'),
        args=['run','--rm','--interactive',IMAGE])
    async with Client(server) as client:
        discovered = (await client.list_tools()).tools
        allowed = {tool.name for tool in discovered}
        print('MCP image:', IMAGE, flush=True)
        print('Discovered:', ', '.join(sorted(allowed)), flush=True)
        tools = [dict(type='function', function=dict(name=t.name,
            description=t.description or t.name, parameters=t.input_schema)) for t in discovered]
        if len(sys.argv)>1 and sys.argv[1]=='list':
            for t in discovered:
                print(t.name, json.dumps(t.input_schema, sort_keys=True))
            return
        question = 'Use the pricing tool to calculate the total for 7 items at 19.5 each. Reply in one sentence using the returned result.'
        print('User:', question, flush=True)
        messages = [dict(role='system',content='Use the provided tool for calculations. Never invent a tool result.'),
            dict(role='user',content=question)]
        trace = dict(model=MODEL,image=IMAGE,tools=tools,question=question,rounds=[],results=[])
        called = False
        for _ in range(4):
            response = await asyncio.to_thread(chat, messages, tools)
            trace['rounds'].append(response)
            message = response['message']
            messages.append(message)
            calls = message.get('tool_calls', [])
            if not calls:
                if not called:
                    raise RuntimeError('The model did not call a tool')
                answer = message['content'].strip()
                if not answer:
                    raise RuntimeError('Empty model response')
                print('Ollama answer:', textwrap.fill(answer, width=89), flush=True)
                trace['answer']=answer
                Path('ollama-trace.json').write_text(json.dumps(trace,indent=2)+'\n')
                return
            for call in calls:
                name, arguments = call['function']['name'], call['function']['arguments']
                if name not in allowed:
                    raise RuntimeError('Unknown requested tool: '+name)
                print('Ollama requested:', name, json.dumps(arguments), flush=True)
                result = await client.call_tool(name, arguments)
                print('MCP is_error:', result.is_error, flush=True)
                print('MCP result:', json.dumps(result.structured_content), flush=True)
                if result.is_error:
                    raise RuntimeError('MCP tool failed')
                payload = result.structured_content
                trace['results'].append(dict(name=name,arguments=arguments,result=payload))
                messages.append(dict(role='tool',tool_name=name,content=json.dumps(payload)))
                called=True
        raise RuntimeError('Tool loop exceeded four turns')


asyncio.run(main())
