"""Prepare explicit inputs for Apizr's OCI builder; this script does not build."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile
from email.parser import BytesParser


def lock_wheels(house, destination):
    rows = []
    for wheel in sorted(Path(house).glob('*.whl')):
        with zipfile.ZipFile(wheel) as archive:
            meta = next(n for n in archive.namelist() if n.endswith('.dist-info/METADATA'))
            identity = BytesParser().parsebytes(archive.read(meta))
        rows.append(f"{identity['Name']}=={identity['Version']} --hash=sha256:{hashlib.sha256(wheel.read_bytes()).hexdigest()}")
    if not rows:
        raise RuntimeError('No wheels found')
    Path(destination).write_text('\n'.join(rows) + '\n')


def prepare():
    root = Path.cwd().resolve()
    docker = str(Path(shutil.which('docker')).resolve())
    info = json.loads(subprocess.check_output([docker, 'image', 'inspect', 'python:3.14-slim']))[0]
    base = info['RepoDigests'][0]
    platform = info['Os'] + '/' + info['Architecture']
    wheels = root / 'mcp-wheels'
    wheels.mkdir(exist_ok=True)
    if not list(wheels.glob('*.whl')):
        subprocess.run([docker, 'run', '--rm', '--platform', platform,
            '--mount', f'type=bind,src={wheels},dst=/wheels',
            '--mount', f'type=bind,src={root}/mcp-bundle/requirements.txt,dst=/requirements.txt,readonly',
            base, 'python', '-m', 'pip', 'download', '--no-cache-dir',
            '--only-binary=:all:', '--dest', '/wheels', '-r', '/requirements.txt'], check=True)
    lock_wheels(wheels, root / 'mcp.lock')
    request = dict(schema='apizr.oci-build/v1', bundle=str(root/'mcp-bundle'),
        interface='mcp', base_image=base, platform=platform,
        tag='apizr-academy:05-shop-mcp', requirements=str(root/'mcp.lock'),
        wheelhouse=str(wheels), timeout_ms=300000, max_log_bytes=1048576,
        docker=dict(executable=docker, socket=str(Path.home()/'.docker/run/docker.sock'),
            buildx='/Applications/Docker.app/Contents/Resources/cli-plugins/docker-buildx'))
    (root/'build.json').write_text(json.dumps(request, indent=2)+'\n')
    inventory = json.loads(subprocess.check_output(['apizr','plugins','list','--active','--json','--plugins-dir',str(root/'plugins')]))
    record = next(r for r in inventory['installations'] if r['name']=='outerspace-apizr-oci')
    identity = {k:record[k] for k in ('name','version','sha256','lock_sha256','dependencies')}
    target = {k:request[k] for k in ('bundle','interface','base_image','platform','tag','requirements','wheelhouse','docker')}
    target['proof_requirement']='optional'
    grant = dict(schema='apizr.operator-policy/v1', grants=[dict(plugin=identity,
        operation='build', target=target, permissions=['image.build','registry.read'])])
    (root/'build-operator.json').write_text(json.dumps(grant,indent=2)+'\n')
    print('Prepared:', len(list(wheels.glob('*.whl'))), 'runtime wheels')
    print('Target:', platform)
    print('Base:', base)
    print('Written: mcp.lock, build.json, build-operator.json')


if __name__=='__main__':
    prepare()
