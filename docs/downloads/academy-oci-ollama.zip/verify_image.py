import json, subprocess
built = json.load(open("build-result.json"))["result"]
actual = json.loads(subprocess.check_output(["docker", "image", "inspect", built["tag"]]))[0]
assert actual["Id"] == built["image_id"]
assert actual["Config"]["User"] == "65532:65532"
assert built["published"] is False
print("Image identity matches the Apizr build result.")
print("Runtime user:", actual["Config"]["User"])
print("Published:", built["published"])
