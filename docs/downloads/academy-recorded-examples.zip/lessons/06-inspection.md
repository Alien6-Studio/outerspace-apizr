# Academy VI — Inspect experiment evidence

Audience: Advanced Python developers and data scientists: realistic evidence, failure modes and technical variants

Learning objective: Identify what a notebook inspection establishes, locate its evidence, and decide what still requires execution. Verify the notebook bytes versus scientific signals boundary on actual evidence.

Preparation transcript; actual recorded results remain in the local review evidence.

## A notebook arrives for review

A colleague sends you a fraud detection notebook and asks whether its result is ready to share. Before spending time on another training run, what can you establish from the notebook itself? We will inspect the real example in this repository: synthetic transactions, a random forest, a held-out test split, three metrics and a saved prediction model. By the end, you will distinguish a source finding from an observed result and explain one missing piece of evidence.

## From source to a review decision

Imagine that the notebook names a ROC AUC calculation and fixes random state to forty two. Does reading that source establish an AUC value? Does the seed establish that the experiment has been reproduced? Keep your answers in mind. Our question is practical: which facts can we use for review now, and which facts require a separately chosen execution?

## Read the experiment, not a shell script

Start with the scientific workflow rather than the command list. The active CSV is the training input. The split reserves a quarter of the rows for evaluation. Twenty four trees and maximum depth five are the visible hyperparameters. Both the split and the forest name a seed. The main guard separates training from prediction. Notice that these are statements in source; we have not loaded the CSV into pandas or fitted a model.

```sh
python lab.py source settings
```

```sh
test ! -e artifacts/model.joblib && echo "No trained model in this fresh copy"
```

## Inspect once; read the eight evidence states

We now ask Apizr to inspect the saved notebook and retain its JSON report. The second command is a teaching projection of that actual file; the complete report remains on disk. Read the execution line first: not executed. Parameters can be captured as static candidates while metrics and outputs remain partial. Captured does not mean scientifically verified. The data section can also remain partial because the model loader contains a dynamic path. A known CSV and an unresolved reference can coexist.

```sh
apizr experiment inspect fraud_detection.ipynb --format json > inspection-a.json
```

```sh
python lab.py inspection inspection-a.json
```

## Read each state in its evidence context

Use three different questions. For data, ask which exact bytes were identified. For parameters, ask whether the value came from source or from execution. For a metric, ask whether we found a calculation or actually observed its value. This prevents a common mistake: treating a visually complete report as an experiment that has already run. The source location is your way back to the notebook when a finding needs explanation.

## Same filename; different data

We replace only the active CSV with the second committed synthetic cohort and inspect again. Before reading the comparison, predict which facts should change. The notebook and its hyperparameters have not been edited. The path is still data slash transactions dot CSV, but its bytes differ because the synthetic label rule differs. The new input digest should expose that change. Neither inspection creates a model or an observed AUC. A familiar filename is not a data version.

```sh
cp data/transactions-b.csv data/transactions.csv
```

```sh
apizr experiment inspect fraud_detection.ipynb --format json > inspection-b.json
```

```sh
python lab.py inspect-change
```

## Variant: notebook bytes versus scientific signals

For an advanced review, distinguish raw notebook identity from the identity of its scientific signals. We deliberately change stored execution counts and presentation metadata without changing any executable cell text. These are fixture edits, not kernel execution. Inspect again and compare both digests. Raw bytes should differ, while the signal digest should remain stable. This lets you explain why a notebook file change need not be a changed scientific signal. Neither identity establishes that the cell actually executed.

```sh
python lab.py presentation
```

```sh
apizr experiment inspect fraud_detection.ipynb --format json > presentation.json
```

```sh
python lab.py signal-check
```

## Your turn: can we report an AUC?

Pause the lesson. A colleague sees captured parameters, a seed and a recognized AUC call, then writes: the model achieved a reproducible score. Identify two unsupported parts of that sentence. Then name the next operation you would choose, and the environment you would need.

## Answer: evidence determines the next action

No AUC value has been observed, because inspection never executed the notebook. A declared seed also does not establish a reproduced outcome across environments. If we trust the notebook, the next step is an explicit experiment Run in the Python environment containing its scientific dependencies. Keep the inspection as a review starting point. We will use that distinction in the next lesson when a Plan becomes a retained Run.

## Continue with the written guide

The current written guide remains authoritative. Continue there for the detailed steps. Thank you for following Apizr Academy.
