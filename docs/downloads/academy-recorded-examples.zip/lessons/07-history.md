# Academy VII — Run an experiment and read its history

Audience: Advanced Python developers and data scientists: realistic evidence, failure modes and technical variants

Learning objective: Execute the fraud notebook, distinguish Plan from Run, and explain what the local history retains. Verify the altered retained evidence is refused boundary on actual evidence.

Preparation transcript; actual recorded results remain in the local review evidence.

## What produced this model file?

You have reviewed the fraud notebook. Now your colleague asks which data and settings produced the saved model on your disk. A model filename alone cannot answer that. In this lesson we execute the trusted notebook and read a retained experiment record. We will connect the intended setup, the observed metrics and the selected model identity, then check what happens when the current CSV is replaced.

## Plan, execution, Run

Think of the lifecycle as three separate steps. A Plan identifies the intended source, inputs and controls. A fresh local Python process executes the workload in the selected environment. The Run records observed facts, including status, selected metrics and output fingerprints. The process has host access, so this is the point at which trusting the notebook matters. Apizr does not install pandas or scikit-learn for you.

## Execute the reviewed notebook

Read the command before running it. Experiment run selects the saved notebook. The output option gives the model a stable logical name and points to its actual file. JSON goes into run a dot JSON so that later commands can use the exact Run identity. During execution the forest is trained and its held-out metrics are calculated. A successful exit says that this execution completed; model quality still needs scientific interpretation.

```sh
apizr experiment run fraud_detection.ipynb --output model=artifacts/model.joblib --format json > run-a.json
```

```sh
python lab.py run run-a.json
```

## Intended values and observed values

Do not merge the Plan and Run into one undifferentiated configuration. A parameter candidate in source and a runtime parameter observation answer different questions. Likewise, a seed in the Plan is not automatically an observed seed in the Run. Look for origin and missing evidence rather than filling the gap yourself. The worker Python and package versions describe the execution environment; requirements text alone describes a specification.

## Read the retained record by identity

List helps discover the retained Run, while show selects one exact identity. We save the complete record and display a short projection so that each line remains readable. Find the three observed metric values, the input digest and the selected model digest. These values come from this actual execution. Precision and recall describe different errors; neither can be replaced by the label successful. Keep the complete JSON when a reviewer needs more than this projection.

```sh
apizr experiment list
```

```sh
RUN_A=$(python -c 'import json; print(json.load(open("run-a.json"))["run_digest"])')
```

```sh
apizr experiment show "$RUN_A" --format json > retained-a.json
```

```sh
python lab.py run retained-a.json
```

## Does history silently follow the current CSV?

Now we deliberately replace the current CSV with cohort B without rerunning the notebook. Predict the effect on Run A. The retained input identity stays tied to A, while the file at the same path now has another digest. This is why a content identity matters. The local history records evidence; it is not a dataset archive or a model registry. If the underlying bytes are overwritten, the recorded digest does not recreate them.

```sh
RUN_A=$(python -c 'import json; print(json.load(open("run-a.json"))["run_digest"])')
```

```sh
cp data/transactions-b.csv data/transactions.csv
```

```sh
python lab.py retain
```

```sh
apizr experiment show "$RUN_A" --format json > retained-a-after.json
```

## Variant: altered retained evidence is refused

Now test the integrity boundary instead of trusting a happy-path report. We copy the local store and append whitespace to one retained Run in that disposable copy. The JSON may still be syntactically readable, but its bytes no longer match the canonical record and filename identity. Show must refuse it. The original history remains available. This demonstrates byte integrity of retained local evidence, not a signed attestation or authorization for another user to trust the experiment.

```sh
cp -R .apizr/experiments/v1 damaged-store
```

```sh
RUN_A=$(python -c 'import json; print(json.load(open("run-a.json"))["run_digest"])'); printf " " >> "damaged-store/runs/$RUN_A.json"
```

Expected refusal: exit 2.

```sh
apizr experiment show "$RUN_A" --store damaged-store --format json > refused.json 2> refused.log
```

```sh
python lab.py refusal
```

## Your turn: what should you preserve?

Pause and answer. You have a Run digest and a selected model fingerprint. Tomorrow you overwrite the model file. Can show restore the previous model? What should you retain separately if another engineer must serve that exact model later? Explain the difference between identifying an artifact and storing the artifact bytes.

## A Run is a reviewable execution record

Show cannot recreate overwritten model bytes. Keep the selected data and model through your own artifact retention process when they must be reused. The Run lets you verify which identities and observations were recorded, and it refuses corrupt retained evidence. You can now explain what produced this observed result and what must be preserved alongside it. Next we record cohort B and compare the two histories.

## Continue with the written guide

The current written guide remains authoritative. Continue there for the detailed steps. Thank you for following Apizr Academy.
