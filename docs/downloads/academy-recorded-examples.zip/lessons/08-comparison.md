# Academy VIII — Compare experiment Runs

Audience: Advanced Python developers and data scientists: realistic evidence, failure modes and technical variants

Learning objective: Compare two real model Runs, read material versus result changes, and formulate a defensible conclusion. Verify the compare a run with itself boundary on actual evidence.

Preparation transcript; actual recorded results remain in the local review evidence.

## A different score is the start of an investigation

Your colleague sees another AUC and asks whether the new model is better. We will compare two actual fraud detection Runs. The notebook, forest settings and seed stay fixed; the active synthetic data changes. Our goal is to find the recorded differences, interpret the metric direction, and state what further evidence would be needed before choosing a model.

## Write the comparison question first

Before running anything, make the comparison question explicit. We expect the input content identity to change, while the source and declared parameters should agree. Observed scores and the saved model may change as a consequence of execution. That expectation is a hypothesis to check against the records. The two synthetic cohorts have identical feature rows but different fraud-label rules, so they are not an unchanged benchmark.

## Record baseline A

We begin with the first cohort in a fresh local project and retain a real baseline Run. The metric values are measured from the held-out split, rather than assigned as constants in a toy script. Read the model and input fingerprints alongside the numbers. This is the evidence we will compare with B. Writing A down before changing data prevents the current working directory from becoming our only memory of the experiment.

```sh
apizr experiment run fraud_detection.ipynb --output model=artifacts/model.joblib --format json > run-a.json
```

```sh
python lab.py run run-a.json
```

## Change the cohort; retain B

Replace only the active CSV, then run the same notebook with the same output selection. The active model path is reused, but the two retained Runs keep their recorded identities. Before looking at the diff, notice the experimental limitation: changing the label rule changes the task being evaluated. Even if one score rises, this setup does not establish an improvement against a fixed real-world evaluation target.

```sh
cp data/transactions-b.csv data/transactions.csv
```

```sh
apizr experiment run fraud_detection.ipynb --output model=artifacts/model.joblib --format json > run-b.json
```

```sh
python lab.py run run-b.json
```

## Separate material evidence from observed results

We select the exact two Run digests and ask for the canonical diff. Read material evidence first: does the input reference match while its content changes? Do intended and observed parameter values agree? Then read the results: metric values and their B minus A deltas. Unknown is its own state. It does not mean same, and it should not be silently counted as unchanged. The projection shows actual diff fields; the full report remains available.

```sh
RUN_A=$(python -c 'import json; print(json.load(open("run-a.json"))["run_digest"])'); RUN_B=$(python -c 'import json; print(json.load(open("run-b.json"))["run_digest"])')
```

```sh
apizr experiment diff "$RUN_A" "$RUN_B" --format json > comparison.json
```

```sh
python lab.py comparison comparison.json
```

## Read the actual metric trade-off

Read AUC, precision and recall side by side in the actual retained comparison. Each row shows A, B and the B minus A delta. A metric direction is not a universal quality ranking: precision and recall answer different error questions, while AUC summarizes ranking across thresholds. More importantly, these cohorts use different label rules. A defensible conclusion names those changed inputs and observed results; a model-quality decision still needs a stable evaluation protocol, an appropriate test population and error analysis.

## Variant: compare a Run with itself

An advanced comparison must preserve unknown evidence even in a self-comparison. Predict what happens when A is compared with A. Known numeric metric deltas should be zero. But the absence of a runtime seed observation does not become evidence that the seed was observed merely because the two record identities match. Read the actual unknown facet count and the parameter states. Identity equality and field-level knowledge are different concepts; your review should preserve both.

```sh
RUN_A=$(python -c 'import json; print(json.load(open("run-a.json"))["run_digest"])')
```

```sh
apizr experiment diff "$RUN_A" "$RUN_A" --format json > self-comparison.json
```

```sh
python lab.py comparison self-comparison.json
```

## Your turn: reverse the comparison

Pause and predict. If we swap A and B, what should happen to a numeric delta? What should happen to a material content difference? Would two missing observations suddenly become known? Write the expected result, then watch the same canonical comparison in the reverse direction.

## Check the prediction against the real reverse diff

The reverse comparison is a useful reading check. Comparable numeric deltas change sign because the subtraction direction changes. Different recorded content still differs. Missing evidence stays unknown rather than becoming a match. Read the actual result before accepting your prediction. This simple check teaches you how to read a comparison rather than memorizing a particular score from this machine.

```sh
RUN_A=$(python -c 'import json; print(json.load(open("run-a.json"))["run_digest"])'); RUN_B=$(python -c 'import json; print(json.load(open("run-b.json"))["run_digest"])')
```

```sh
apizr experiment diff "$RUN_B" "$RUN_A" --format json > reverse.json
```

```sh
python lab.py comparison reverse.json
```

## From a score to a review question

We have compared two measured model Runs, separated material and result changes, and checked the direction of the diff. Keep this habit: state the question, hold an appropriate baseline, inspect evidence origins and explain the remaining uncertainty. The next lesson makes another explicit choice: which retained prediction and which model bytes should be included in an interface?

## Continue with the written guide

The current written guide remains authoritative. Continue there for the detailed steps. Thank you for following Apizr Academy.
