# Academy IX — Expose a selected prediction

Audience: Advanced Python developers and data scientists: realistic evidence, failure modes and technical variants

Learning objective: Explain the serving boundary, select a retained model and capability, and inspect the generated REST and MCP bindings. Verify the replaced model bytes block exposure boundary on actual evidence.

Preparation transcript; actual recorded results remain in the local review evidence.

## Share prediction without rerunning training

An application team wants to call the fraud model. Giving them the whole notebook leaves important questions unanswered: which Run, which model, which function and which dependencies? We will use a successful Run from the same example to generate one selected prediction interface. By the end you will explain why a training artifact, a serving selection and a deployment are different things.

## Draw the serving boundary first

The notebook trains inside a main guard and defines prediction separately. Importing the prediction module must not retrain the forest. The prediction needs the selected model, joblib, scikit-learn and the feature-order helper. Pandas belongs to training here. These concrete dependencies are more useful than exposing every callable found in a repository. Our public surface will be one prediction accepting a typed transaction.

## Inspect what predict really needs

Read the actual predict function. It loads the saved model and uses the shared helper to construct the feature row in the expected order. The transaction has an amount, a velocity, a foreign-transaction flag and account age. The return carries a classification and probability. These are ordinary workload choices; Apizr does not invent the prediction logic. The main guard keeps training out of module import, while dependencies still need explicit serving evidence.

```sh
python lab.py source predict
```

```sh
python lab.py source settings
```

## Retain the model that will be selected

For this independent lesson we start from a fresh copy, select cohort B and execute the reviewed notebook. We give the model its explicit logical name. Read the retained output identity before generation: this is the artifact we intend to bind. The training marker helps us distinguish an experiment-side file from a serving selection. Generating the interfaces later must not be treated as a new training run.

```sh
cp data/transactions-b.csv data/transactions.csv
```

```sh
apizr experiment run fraud_detection.ipynb --output model=artifacts/model.joblib --format json > run-b.json
```

```sh
python lab.py run run-b.json
```

## Four choices you must be able to explain

Name the four choices before typing the expose command. The Run digest selects retained evidence. The capability identifier selects prediction. The artifact name selects the recorded model bytes. The dependency wheelhouse supplies evidence for the external packages. Conditional allowance acknowledges that external code remains opaque; it is not a certificate of safe initialization. Missing or stale required evidence is a reason to stop and investigate.

## Generate the two explicit bindings

We create a narrow operator grant for this copied local project. Expose then selects the Run, prediction capability, model and scientific dependencies. The interface option changes between REST and MCP, while the selected Run stays the same. These commands create local bundles. They do not start a server or contact a registry. Keep the complete generated reports so that a reviewer can inspect the actual selection and its dependency evidence.

```sh
python -c 'import json; from pathlib import Path; Path("operator.json").write_text(json.dumps({"schema":"apizr.operator-policy/v1","grants":[{"adapter":"repository","operation":"analyze","target":{"kind":"local","root":str(Path.cwd())},"permissions":["source.analyze"]}]}))'
```

```sh
RUN_B=$(python -c 'import json; print(json.load(open("run-b.json"))["run_digest"])')
```

```sh
for interface in rest mcp; do apizr experiment expose "$RUN_B" --root . --operator-policy operator.json --capability python:fraud_detection:predict --interface "$interface" --artifact model --dependency scikit-learn --dependency joblib --dependency-wheelhouse "$SCIENCE_WHEELHOUSE" --allow-conditional --output-dir "bundles/$interface" > "$interface-exposure.json"; done
```

```sh
python lab.py binding
```

## Variant: replaced model bytes block exposure

Test the binding against a stale artifact, not just a valid model. We save the selected model, then deliberately alter the bytes at its current path. The original Run still identifies the old model. Expose must refuse the mismatch instead of binding the new bytes under the old evidence. We read the actual refusal and restore the selected bytes, checking their digest. This is why an artifact path, an artifact identity and a retained artifact copy are three separate operational concerns.

```sh
RUN_B=$(python -c 'import json; print(json.load(open("run-b.json"))["run_digest"])')
```

```sh
cp artifacts/model.joblib artifacts/original-model.joblib; printf "altered" >> artifacts/model.joblib
```

Expected refusal: exit 2.

```sh
apizr experiment expose "$RUN_B" --root . --operator-policy operator.json --capability python:fraud_detection:predict --interface rest --artifact model --dependency scikit-learn --dependency joblib --dependency-wheelhouse "$SCIENCE_WHEELHOUSE" --allow-conditional --output-dir bundles/stale > refused.json 2> refused.log
```

```sh
python lab.py refusal
```

```sh
python lab.py restore-model
```

## Your turn: a newer model appears at the path

Pause here. Another training run overwrites model dot joblib after the selected Run was recorded. Should the original Run silently pick up that newer model when exposed? Which fact would you compare before continuing? Also explain why training completed dot text should not become a serving dependency merely because it exists in the experiment folder.

## Bind evidence before you discuss deployment

A different file at the same path is not the selected recorded model. Preserve and verify the intended bytes instead of silently substituting a newer artifact. Only selected serving artifacts belong in the binding. REST and MCP describe two interfaces around this selection; real calls, runtime isolation, operations and deployment need their own qualification. You now have a reviewable handoff with a clear serving boundary.

## Continue with the written guide

The current written guide remains authoritative. Continue there for the detailed steps. Thank you for following Apizr Academy.
