# Academy X — Capture Python calls with sessions and decorators

Audience: Advanced Python developers and data scientists: realistic evidence, failure modes and technical variants

Learning objective: Choose session versus decorator, record meaningful threshold metrics and compare calls without changing return values. Verify the failed capture preserves the exception boundary on actual evidence.

Preparation transcript; actual recorded results remain in the local review evidence.

## The same model can make different review queues

The fraud model emits a probability. Your team must choose when to flag a transaction for review. A lower threshold can flag more transactions, while precision and recall describe different mistakes. In this lesson we evaluate a real held-out synthetic sample from our trained forest. We will capture one evaluation block with a session, then compare two ordinary function calls with a decorator.

## Decide what one Run should mean

Choose the unit you want to review. A session suits a block with several operations and observations. A decorator suits repeated function calls, where each call becomes a Run. In both cases explicitly select parameters, inputs and metrics. Tracking should preserve your function return and exception behavior. It does not infer every meaningful variable in your program or decide which metric the business should optimize.

## Inspect the held-out sample and metric calculation

The preparation step has trained the same example in this fresh copy and retained its baseline Run. Now we derive the exact held-out rows using the notebook split and saved model. Evaluation dot CSV contains labels and the actual predicted probabilities. Our small evaluator counts true positives, false positives and false negatives, then computes precision and recall. Unlike a hard-coded score, these values depend on the selected sample and threshold. The sample remains synthetic and is not a production benchmark.

```sh
python lab.py prepare-holdout
```

```sh
python lab.py source evaluate
```

## Record a block with named evidence

Read the session code first. The input call fingerprints the actual evaluation file. The parameter call records threshold zero point five, and the loop records the observed metric values. Run the code, then read the returned result and retained Run identity. The distinction matters: the return is still an ordinary Python value used by your program; the record is the evidence you chose to retain for later review.

```sh
python lab.py source session_example
```

```sh
python thresholds.py session
```

## Why report precision and recall together?

Precision asks how many flagged rows were actually labelled fraudulent. Recall asks how many labelled fraudulent rows were found. The flagged count describes review volume in this particular sample. Changing a threshold can trade one concern against another, so a single best score is not enough to define a review policy. These metrics are observed values over selected data, and the data identity is part of their interpretation.

## Compare two calls; keep their normal results

The decorator selects threshold from the function arguments. Each call logs the same input file and its observed metrics. We call thresholds zero point three five and zero point six five, and verify that tracking leaves their ordinary return values unchanged. Before reading the output, predict which call should flag at least as many rows. Compare the recorded precision and recall rather than assuming that either threshold is automatically preferable.

```sh
python lab.py source tracked_evaluate
```

```sh
python thresholds.py calls
```

```sh
python lab.py history
```

## Variant: failed capture preserves the exception

A useful SDK integration must survive failures without changing program behavior. This evaluation deliberately logs a partial observation, then raises a synthetic ValueError. The caller catches that same exception outside the decorated function. We check the retained failed Run and verify that its exception message is absent from the record. Failure status and explicitly logged observations can be useful evidence; a complete traceback is not silently made part of the experiment. This is also why successful function returns alone are an incomplete qualification of a tracking integration.

```sh
python lab.py source failed_review
```

```sh
python thresholds.py failure
```

```sh
python lab.py failure-check
```

## Your turn: an in-memory array replaces the file

Pause and explain what changes if the program logs only an input name for an in-memory array, instead of identifying evaluation dot CSV. Does that input name fingerprint its contents? Would an unchanged name establish that two evaluations used the same values? Then decide what evidence you would record for a review that must compare actual input content.

## Capture the evidence your decision needs

An input name alone does not establish an in-memory content identity. A selected local file can be fingerprinted, as in this lesson; other unknowns must stay visible. Choose a session for a block or a decorator for repeated calls, and keep the same input definition when comparing their outcomes. The SDK makes these observations reviewable without selecting your threshold policy. Next we use these same evaluation ideas in a real live kernel.

## Continue with the written guide

The current written guide remains authoritative. Continue there for the detailed steps. Thank you for following Apizr Academy.
