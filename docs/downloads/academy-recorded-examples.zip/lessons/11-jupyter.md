# Academy XI — Capture real Jupyter cells

Audience: Advanced Python developers and data scientists: realistic evidence, failure modes and technical variants

Learning objective: Read real kernel cell identity and execution count, and distinguish repeated calls from saved notebook content. Verify the the unlogged calibration offset boundary on actual evidence.

Preparation transcript; actual recorded results remain in the local review evidence.

## The notebook screen is not the whole execution history

In a notebook you can rerun a cell after changing a threshold or changing kernel state. The visible output is then only the latest display for that cell. How do you review the actual calls you made? We use the same fraud holdout evaluation from the SDK lesson inside a real installed ipykernel. We will repeat a cell and inspect the retained evidence rather than relying on its position on screen.

## Three identities to keep separate

A saved notebook has a file identity. A running cell has an identity supplied by its frontend and an execution count assigned by the kernel. An experiment Run has its own retained digest. These identities answer different questions. Repeating a cell can keep its cell identifier while advancing execution count and creating another Run. It does not establish that the notebook was saved or that all earlier cells were executed in order.

## Predict the number of retained captures

Our notebook loads the real evaluation sample, captures one evaluation session, defines a decorated evaluator and calls it at two thresholds. We then repeat the first call cell. Predict how many Runs should remain: defining a function is not an evaluation call. Also predict whether the repeated cell will share its identifier, its execution count and its Run digest. We will check these distinctions against actual kernel messages.

## Execute the actual cells and repeat a call

This recording sends the prepared notebook cells to a real ipykernel using the candidate interpreter. The displayed source and outputs are actual kernel messages. Watch the session result, the two threshold evaluations and the repeated first variant. Our capture is a terminal view of that live kernel, not a recording of a notebook frontend. We keep the original cell identifiers and record each returned execution count so that the repetition can be verified afterwards.

```sh
python -m scripts.qualification.experiments.academy_kernel --notebook fraud-thresholds.ipynb --workspace "$APIZR_ACADEMY_KERNEL_WORKSPACE" --input evaluation.csv --pause 3
```

## Read cell evidence in the shared history

Now read the store created by those kernel executions. We expect one session capture and three decorated-call captures. Find the first variant cell twice: its cell identifier is the same, while its execution count differs. The metrics remain observations of the selected evaluation file and threshold. Separate Runs keep the history of repeated work instead of replacing the previous cell display.

```sh
apizr experiment list --store "$APIZR_ACADEMY_KERNEL_WORKSPACE/.apizr/experiments/v1"
```

```sh
(cd "$APIZR_ACADEMY_KERNEL_WORKSPACE" && python "$APIZR_ACADEMY_LAB" history)
```

## Variant: the unlogged calibration offset

The final notebook cell deliberately changes a calibration offset in live memory before the first variant is repeated. Its threshold and selected CSV identity stay the same, but the classification calculation reads that changed offset. Read the two actual results from the repeated cell. Cell identity plus an input file digest is not a complete kernel-state snapshot. The correction is practical: explicitly log calibration offset as a parameter and preserve the relevant source, rather than claiming that matching cell identifiers establish equivalent executions.

## What this does not reveal about kernel state

Execution counts tell you about order in this kernel; they are not a complete snapshot of memory. A repeated cell may read variables created earlier or modified elsewhere. Logging the evaluation file gives us content evidence for that selected input, but does not turn every live object into a verified snapshot. A saved notebook can also differ from the currently executing cell. Keep these limits explicit when explaining a result to a colleague.

## Your turn: same cell, same result?

Pause and answer. You rerun the same cell identifier with the same threshold but have changed an unlogged in-memory array. Must the metric stay the same? Does a new execution count tell you which array values were used? Explain what you would log or preserve to make that comparison useful.

## Review the execution, not just the latest display

The same cell can produce another result when its live inputs differ. Its execution count alone cannot identify those values. Our real notebook example produces four retained captures, including two executions of the first variant cell. You can now read the shared history without confusing a cell, its latest display and a saved file. The VS Code lesson uses the same retained evidence; its native recording remains a separate task.

## Continue with the written guide

The current written guide remains authoritative. Continue there for the detailed steps. Thank you for following Apizr Academy.
