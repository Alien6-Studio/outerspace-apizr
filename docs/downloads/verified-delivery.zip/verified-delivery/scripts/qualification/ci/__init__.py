"""Ci qualification ownership boundary."""
