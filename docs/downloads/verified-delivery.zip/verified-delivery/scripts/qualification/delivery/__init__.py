"""Delivery qualification ownership boundary."""
