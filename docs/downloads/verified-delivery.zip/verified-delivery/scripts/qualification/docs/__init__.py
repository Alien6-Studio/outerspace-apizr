"""Docs qualification ownership boundary."""
