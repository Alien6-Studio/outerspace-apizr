"""Extensions qualification ownership boundary."""
