"""Fixtures qualification ownership boundary."""
