"""Interfaces qualification ownership boundary."""
