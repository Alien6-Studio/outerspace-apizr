"""Packaging qualification ownership boundary."""
