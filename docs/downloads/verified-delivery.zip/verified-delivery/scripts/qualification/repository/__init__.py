"""Repository qualification ownership boundary."""
